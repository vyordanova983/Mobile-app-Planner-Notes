package com.example.plannernoteuni;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class updateDelete extends AppCompatActivity {

    protected void CloseThisActivity(){
        finishActivity(200);
        Intent i=new Intent(updateDelete.this, MainActivity.class);
        startActivity(i);
    }



    //член променливи
    protected String ID;
    protected EditText udPlace, udTown, udCountry;
    protected Button btnUpdate, btnDelete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);

        udPlace=findViewById(R.id.udPlace);
        udTown=findViewById(R.id.udTown);
        udCountry=findViewById(R.id.udCountry);
        btnUpdate=findViewById(R.id.btnUpdate);
        btnDelete=findViewById(R.id.btnDelete);

        //взима и визуализира входните данни
        Bundle b=getIntent().getExtras();
        if (b!=null){
            ID=b.getString("ID");
            udPlace.setText(b.getString("place"));
            udTown.setText(b.getString("town"));
            udCountry.setText(b.getString("country"));
        }
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db=null;
                try {
                    db=SQLiteDatabase.openOrCreateDatabase(
                            getFilesDir().getPath()+"/"+"notesplanner.db",
                            null
                    );
                    String place=udPlace.getText().toString();
                    String town=udTown.getText().toString();
                    String country=udCountry.getText().toString();
                    String q="UPDATE NOTESPLANNER SET place=?, town=?, country=?";
                    q+="WHERE ID=?;";

                    //шаблон за вградена защита
                    db.execSQL(q, new Object[]{place, town, country, ID});
                    //за инфо на потребителя, че инсърта е успешен
                    Toast.makeText(getApplicationContext(),
                            "Update seccessful", Toast.LENGTH_LONG)
                            .show();

                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getLocalizedMessage(),
                            Toast.LENGTH_LONG).show();
                }finally {
                    if (db!=null){
                        db.close();
                        db=null;
                    }
                }
                CloseThisActivity();
            }
        });


        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db=null;
                try {
                    db=SQLiteDatabase.openOrCreateDatabase(
                            getFilesDir().getPath()+"/"+"notesplanner.db",
                            null
                    );
                    String q="DELETE FROM NOTESPLANNER WHERE ID=?";

                    db.execSQL(q, new Object[]{ID});
                    //за инфо на потребителя, че инсърта е успешен
                    Toast.makeText(getApplicationContext(),
                            "Delete seccessful", Toast.LENGTH_LONG)
                            .show();

                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getLocalizedMessage(),
                            Toast.LENGTH_LONG).show();
                }finally {
                    if (db!=null){
                        db.close();
                        db=null;
                    }
                }
                CloseThisActivity();
            }
        });
    }
}
