package com.example.plannernoteuni;

import androidx.annotation.CallSuper;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //интерфейсни променливи
    protected EditText inputPlace, inputTown, inputCountry;
    protected Button btnInsert,map;
    protected ListView simpleList;


    protected void initDB() throws SQLException{
        SQLiteDatabase db=null;
        db=SQLiteDatabase.openOrCreateDatabase(
                getFilesDir().getPath()+"/"+"notesplanner.db",
                null

        );
        String q="CREATE TABLE if not exists NOTESPLANNER(";
        q+=" ID integer primary key AUTOINCREMENT, ";
        q+=" place text not null, ";
        q+=" town text not null, ";
        q+=" country text not null, ";
        q+=" unique(place, town) );";

        db.execSQL(q);
        db.close();
    }

    public void selectDB() throws SQLException{
        SQLiteDatabase db=null;
        db=SQLiteDatabase.openOrCreateDatabase(
                getFilesDir().getPath()+"/"+"notesplanner.db",
                null

        );
        simpleList.clearChoices();

        ArrayList<String> listResults=new ArrayList<String>();
        String q="SELECT * FROM NOTESPLANNER ORDER BY place;";
        Cursor c=db.rawQuery(q, null);
        while (c.moveToNext()){
            String place=c.getString(c.getColumnIndex("place"));
            String town=c.getString(c.getColumnIndex("town"));
            String country=c.getString(c.getColumnIndex("country"));
            String ID=c.getString(c.getColumnIndex("ID"));
            listResults.add((ID+"\t"+place+"\t"+town+"\t"+country));
        }

        ArrayAdapter<String> arrayAdapter=
                new ArrayAdapter<String>(
                        getApplicationContext(),
                        R.layout.activity_list_view,
                        R.id.textView,
                        listResults
                );
        simpleList.setAdapter(arrayAdapter);
        db.execSQL(q);
        db.close();
    }

    //актуализира резултата след update или delete
    @Override
    @CallSuper
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        //актуализира данните във вю-то
        try {
            selectDB();
        }catch (Exception e){

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputPlace=findViewById(R.id.place);
        inputTown=findViewById(R.id.town);
        inputCountry=findViewById(R.id.country);
        btnInsert=findViewById(R.id.btnInsert);



        simpleList=findViewById(R.id.simpleList);
        simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selected="";
                TextView clickedText=view.findViewById(R.id.textView);
                selected=clickedText.getText().toString();
                String[] elements=selected.split("\t");
                String ID=elements[0];
                String Place=elements[1];
                String Town=elements[2];
                String Country=elements[3];
                //всяко ново активити, което се стартира минава през променлива intent
                Intent intent =new Intent(MainActivity.this, updateDelete.class);
                Bundle b=new Bundle();
                b.putString("ID", ID);
                b.putString("place", Place);
                b.putString("town", Town);
                b.putString("country", Country);

                intent.putExtras(b);
                startActivityForResult(intent, 200, b);

            }
        });

        try {
            initDB();
            selectDB();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(), e.getLocalizedMessage(),
                    Toast.LENGTH_LONG).show();
        }

        map = (Button) findViewById(R.id.btnMap);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=null;
                try {
                    db=SQLiteDatabase.openOrCreateDatabase(
                            getFilesDir().getPath()+"/"+"notesplanner.db",
                            null
                    );
                    String place=inputPlace.getText().toString();
                    String town=inputTown.getText().toString();
                    String country=inputCountry.getText().toString();

                    //проверка за празен запис
                    if (place!="" && !town.equals("") && country!=""){
                        String q="INSERT INTO NOTESPLANNER (place, town, country) ";
                        q+="VALUES(?, ?, ?);";
                        db.execSQL(q, new Object[]{place, town, country});

                        //за инфо на потребителя, че инсърта е успешен
                        Toast.makeText(getApplicationContext(),
                                "Insert seccessful", Toast.LENGTH_LONG)
                                .show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),
                                "Insert was NOT seccessful", Toast.LENGTH_LONG)
                                .show();
                    }


                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getLocalizedMessage(),
                            Toast.LENGTH_LONG).show();
                }finally {
                    if (db!=null){
                        db.close();
                        db=null;
                        //изчистване на текстовите полета
                        inputPlace.setText("");
                        inputTown.setText("");
                        inputCountry.setText("");
                    }
                }
                //пълнене наново на лист вю-то
                try {
                    selectDB();
                }catch (Exception e){

                }
            }
        });
    }
    public void openMap(){
        Intent intent = new Intent(this, LocationFinder.class);
        startActivity(intent);
    }
}
